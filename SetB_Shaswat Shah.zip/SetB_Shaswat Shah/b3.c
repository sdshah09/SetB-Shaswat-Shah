#include<stdio.h>
#include<stdlib.h>
int normalBit(int num){
    int arr[10];
    int i, j;
   
    printf("enter number:");
    scanf("%d",&num);
    
    for(i = 0; num > 0; i++)
    {
        arr[i] = num % 2;
        num = num / 2;
        printf("%d",arr[i]);
    }
    printf("\n");
    
    for (i=10;i>=0;i--){
        if(arr[i]==0 || arr[i]==1){
        printf("%d",arr[i]);
    }
    
    }
    
}

int main(int num)
{
    normalBit(num);
    //reverseBits(num);
    return(0);
}
